﻿Microsoft.Azure.AppService.ApiApps.Service Nuget package.
