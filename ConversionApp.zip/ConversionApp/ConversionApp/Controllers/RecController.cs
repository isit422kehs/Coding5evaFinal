﻿using ConversionApp.Models;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConversionApp.Controllers
{
    public class RecController : ApiController
    {
        MongoDatabase mongoDb = MongoConnect.GetMongoDb();

        public IEnumerable<Recents> GetRecents(string users)
        {
            BsonValue recentList;
            try
            {
                mongoDb.GetCollection("Users").FindOne(Query.EQ("UserName", users)).
                    TryGetValue("Recents", out recentList);

                return
              (from recentEntry in recentList.AsBsonArray.AsEnumerable()
               select new Recents
               {
                   From = recentEntry["From"].AsString,
                   To = recentEntry["To"].AsString,

               }).ToList();

            }
            catch (Exception e)
            {
                throw new ApplicationException(e.ToString());
            }

        }
    }
}
